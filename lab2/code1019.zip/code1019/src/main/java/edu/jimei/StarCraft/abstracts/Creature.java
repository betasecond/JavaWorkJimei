package edu.jimei.StarCraft.abstracts;

import edu.jimei.StarCraft.interfaces.RaceInterface;

abstract public class Creature implements RaceInterface {
    private String life;
    public void fight(){

    };
}
