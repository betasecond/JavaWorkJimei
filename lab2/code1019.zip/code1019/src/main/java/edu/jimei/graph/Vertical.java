package edu.jimei.graph;

import edu.jimei.SomeException;
import lombok.Getter;
import lombok.Setter;

import java.util.logging.Level;
import java.util.logging.Logger;

@Getter @Setter
public class Vertical extends Shape {
    private final static Logger LOGGER = Logger.getLogger(Vertical.class.getName());

    Vertical() {
        super();
        LOGGER.setLevel(Level.INFO); // 设置日志级别
    }

    @Override
    public void addPoints(double x, double y, String id) {
        LOGGER.info("输入格式: x:double, y:double, id:String (例如, \"D1\", \"D2\" 代表对角线上的两个点)");

        DataPoint tempDatapoints = new DataPoint(x, y, id);
        this.getDataPoints().addElement(tempDatapoints);
    }

    @Override
    public void colour(String code) {
        Color colorEnum = Color.forCode(code); // 使用静态方法获取枚举实例

        if (colorEnum == null) {
            System.out.println("Invalid color code: " + code);
        } else {
            this.setColor(colorEnum); // 设置颜色
        }
    }

    private double[] calculateSides() throws SomeException {
        DataPoint pointD1 = null, pointD2 = null;

        // 从数据点集合中找到特定的点
        for (DataPoint point : getDataPoints()) {
            if ("D1".equals(point.getId())) {
                pointD1 = point;
            } else if ("D2".equals(point.getId())) {
                pointD2 = point;
            }
        }

        // 确保找到了必要的点
        if (pointD1 == null || pointD2 == null) {
            throw new SomeException("错误: 对角线上的点未完全提供。");
        }

        double width = Math.abs(pointD2.getX() - pointD1.getX());
        double height = Math.abs(pointD2.getY() - pointD1.getY());

        return new double[]{width, height};
    }

    @Override
    public double getArea() throws SomeException {
        double[] sides = this.calculateSides();
        double area = sides[0] * sides[1]; // 宽度 x 高度

        if (area == 0) {
            throw new SomeException("错误: 矩形面积为0（可能是因为至少一条边的长度为0）");
        }

        return area;
    }
}
