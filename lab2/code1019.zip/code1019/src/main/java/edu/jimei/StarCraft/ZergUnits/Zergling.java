package edu.jimei.StarCraft.ZergUnits;

import edu.jimei.StarCraft.interfaces.UnitsInterface;
import edu.jimei.StarCraft.races.Zerg;
import lombok.Getter;
import lombok.Setter;

@Setter @Getter
public class Zergling extends Zerg implements UnitsInterface {
    private int life = 35;
    private int attackDamage = 5;
    private int range = 1;
    private double speed = 2.612;
    private final int cost = 25;
    private final int buildTime = 12;
    private int armor = 0;

    @Override
    public boolean isAirUnit() {
        return false;
    }

    /**
     * @param target
     */
    @Override
    public void attack(UnitsInterface target) {

    }

    /**
     * @param x
     * @param y
     */
    @Override
    public void move(double x, double y) {

    }

    /**
     * @param damage
     */
    @Override
    public void takeDamage(int damage) {
        this.life -= damage;
    }
    // ... 其他方法 ...
}
