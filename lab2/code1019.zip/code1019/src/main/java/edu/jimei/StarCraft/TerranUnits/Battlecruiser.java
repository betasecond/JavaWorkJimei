package edu.jimei.StarCraft.TerranUnits;

import edu.jimei.StarCraft.interfaces.UnitsInterface;
import edu.jimei.StarCraft.races.Terran;
import lombok.Getter;
import lombok.Setter;

// Terran - Battlecruiser
@Getter @Setter
public class Battlecruiser extends Terran implements UnitsInterface {
    private int life = 400;
    private int attackDamage = 25;
    private int range = 6;
    private double speed = 1.875;
    private final int cost = 400;
    private final int buildTime = 64;
    private int armor = 3;

    @Override
    public boolean isAirUnit() {
        return true;
    }

    /**
     * @param target
     */
    @Override
    public void attack(UnitsInterface target) {

    }

    /**
     * @param x
     * @param y
     */
    @Override
    public void move(double x, double y) {

    }

    /**
     * @param damage
     */
    @Override
    public void takeDamage(int damage) {
        this.life -= damage;
    }
    // ... 其他方法 ...
}