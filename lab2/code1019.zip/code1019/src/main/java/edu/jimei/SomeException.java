package edu.jimei;

public class SomeException extends Exception {
    public SomeException(String message) {
        super(message);
    }
}