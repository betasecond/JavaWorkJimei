package edu.jimei.one.Junior;

import edu.jimei.SomeException;
import edu.jimei.one.Student.Student;
import edu.jimei.one.Student.Study;

public class Junior extends Student implements Study {
    public Junior(String Name) throws SomeException {
        super(Name);
    }

    @Override
    public void study() {
        System.out.println("Junior "+this.getStudentName()+" is using classroom");
        this.setLearnedClass(this.getLearnedClass()+1);
    }
}
