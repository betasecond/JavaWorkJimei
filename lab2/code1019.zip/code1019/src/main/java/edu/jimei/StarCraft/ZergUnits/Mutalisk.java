package edu.jimei.StarCraft.ZergUnits;

import edu.jimei.StarCraft.interfaces.UnitsInterface;
import edu.jimei.StarCraft.races.Zerg;
import lombok.Getter;
import lombok.Setter;

@Setter @Getter
public class Mutalisk extends Zerg implements UnitsInterface {
    private int life = 120; // 仅作为示例，实际值可能会不同
    private int attackDamage = 9; // 示例值
    private int range = 3;  // 示例值
    private double speed = 3.75;  // 示例值
    private final int cost = 100;  // 示例值
    private final int buildTime = 33;  // 示例值
    private int armor = 0;  // 示例值

    @Override
    public boolean isAirUnit() {
        return true;
    }

    /**
     * @param target
     */
    @Override
    public void attack(UnitsInterface target) {

    }

    /**
     * @param x
     * @param y
     */
    @Override
    public void move(double x, double y) {

    }

    /**
     * @param damage
     */
    @Override
    public void takeDamage(int damage) {
        this.life -= damage;
    }


}
