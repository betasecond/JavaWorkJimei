package edu.jimei.graph;

import edu.jimei.SomeException;
import lombok.Getter;
import lombok.Setter;

import java.util.logging.Level;
import java.util.logging.Logger;
@Getter @Setter
public class Circle extends Shape{
    private final static Logger LOGGER = Logger.getLogger(Circle.class.getName());

    Circle(){
        super();
        LOGGER.setLevel(Level.INFO); // 设置日志级别
    }
    @Override
    public void addPoints(double x,double y,String id){
        LOGGER.info("输入格式:x:double,y:double,id:String(A..C)");
        LOGGER.info("请输入一条圆心弦的圆上两点和圆心,而非单纯各边顶点");

        DataPoint tempDatapoints = new DataPoint(x,y,id);
        this.getDataPoints().addElement(tempDatapoints);
    }
    /**
     *
     */
    @Override
    public void colour(String code) {
       Color colorEnum = Color.forCode(code); // 使用静态方法获取枚举实例

        if (colorEnum == null) {
            System.out.println("Invalid color code: " + code);
        } else {
            this.setColor(colorEnum);
        }
    }
    private double calculateRadius() throws SomeException{
        DataPoint pointA = null, pointB = null, pointC = null;

        // 从数据点集合中找到特定的点
        for (DataPoint point : getDataPoints()) {
            switch (point.getId()) {
                case "A" -> pointA = point;
                case "B" -> pointB = point;
                case "C" -> pointC = point;
            }
        }

        // 确保找到了必要的点
        if (pointA == null || pointB == null || pointC == null) {
            throw new SomeException("错误:有点为空");
        }

        // 计算半径（使用点A和点B之间的距离）
        return Math.sqrt(Math.pow(pointB.getX() - pointA.getX(), 2) + Math.pow(pointB.getY() - pointA.getY(), 2));
    }
    private double calculateAreas(double radius) throws SomeException{
        if(radius == 0) {throw new SomeException("错误:半径为0");}
        return radius*radius*Math.PI;
    }
    /**
     * @return
     */
    //circle
    @Override
    public double getArea() throws SomeException{
        double radius = this.calculateRadius();
        if (radius == 0){
            throw new SomeException("错误:半径为0");
        }
        double result = calculateAreas(radius);

        return result;
    }
}
