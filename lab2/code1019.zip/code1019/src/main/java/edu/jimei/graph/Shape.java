package edu.jimei.graph;


import lombok.Getter;
import lombok.Setter;

import java.security.KeyPair;
import java.util.Vector;
@Getter @Setter
abstract public class Shape implements Coloring {
    private int sides;
    private Color color;
    private Vector<DataPoint> dataPoints;
    public Shape() {
        dataPoints = new Vector<DataPoint>();
    }

}
