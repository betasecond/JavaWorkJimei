package edu.jimei.StarCraft.races;

import edu.jimei.StarCraft.abstracts.Creature;
import edu.jimei.StarCraft.interfaces.ZergInterface;

public class Zerg extends Creature implements ZergInterface {
    protected int hiveMind;
    protected int evolutionLevel;
    protected int biomass;

    /**
     *
     */
    @Override
    public void fight() {

    }

    /**
     *
     */
    @Override
    public void move() {

    }

    /**
     *
     */
    @Override
    public void repair() {

    }

    /**
     *
     */
    @Override
    public void recover() {

    }
}
