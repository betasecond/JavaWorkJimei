package edu.jimei.graph;

import edu.jimei.SomeException;

public interface Coloring {
    void colour(String color);
    double getArea() throws SomeException;
    void addPoints(double x,double y,String id);
}
