package edu.jimei.StarCraft.TerranUnits;

import edu.jimei.StarCraft.interfaces.UnitsInterface;
import edu.jimei.StarCraft.races.Terran;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Marine extends Terran implements UnitsInterface {
    private int life = 45;
    private int attackDamage = 6;
    private int range = 5;
    private double speed = 2.25;
    private final int cost = 50;
    private final int buildTime = 25;
    private int armor = 1;
    @Override
    public void attack(UnitsInterface target) {
        // 实现攻击逻辑
    }

    @Override
    public void move(double x, double y) {
        // 实现移动逻辑
    }

    /**
     * @param damage
     */
    @Override
    public void takeDamage(int damage) {
        this.life -= damage;
    }

    @Override
    public boolean isAirUnit() {
        return false;
    }
}
