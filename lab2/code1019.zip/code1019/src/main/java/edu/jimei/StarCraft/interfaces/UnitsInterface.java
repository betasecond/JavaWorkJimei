package edu.jimei.StarCraft.interfaces;

public interface UnitsInterface extends RaceInterface {
    boolean isAirUnit();

    int getLife();
    void setLife(int life);

    int getAttackDamage();
    void setAttackDamage(int damage);

    int getRange();
    void setRange(int range);

    double getSpeed();
    void setSpeed(double speed);

    int getCost();

    int getBuildTime();

    int getArmor();
    void setArmor(int armor);

    void attack(UnitsInterface target);
    void move(double x, double y);

    public void takeDamage(int damage);
}
