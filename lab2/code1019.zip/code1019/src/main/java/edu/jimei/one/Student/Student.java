package edu.jimei.one.Student;

import edu.jimei.SomeException;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public abstract class Student {
    protected String studentName;
    protected String studentId;
    protected int studentAge;
    protected int learnedClass;

    public Student(String Name) throws SomeException {
        if ("None".equals(Name)) {
            throw new SomeException("Name should not be None.");
        }
        setStudentName(Name);
    }
}
