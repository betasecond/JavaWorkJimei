package edu.jimei.one.Graduate;

import edu.jimei.SomeException;
import edu.jimei.one.Student.Student;
import edu.jimei.one.Student.Study;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class Graduate extends Student implements Study {
    public Graduate(String Name) throws SomeException {
        super(Name);
    }

    @Override
    public void study() {
        System.out.println("Graduate "+this.getStudentName()+" is using classroom");
        this.setLearnedClass(this.getLearnedClass()+1);
    }
}
