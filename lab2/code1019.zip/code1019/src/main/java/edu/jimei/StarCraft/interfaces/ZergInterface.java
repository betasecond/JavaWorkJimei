package edu.jimei.StarCraft.interfaces;

public interface ZergInterface extends ProtossInterface {

    void recover();
}
