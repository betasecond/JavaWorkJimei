package edu.jimei.StarCraft.interfaces;

public interface TerranInterface extends RaceInterface {
    void repair();
}
