package edu.jimei.one.Undergraduate;

import edu.jimei.SomeException;
import edu.jimei.one.Student.Student;
import edu.jimei.one.Student.Study;

public class Ungergraduate extends Student implements Study {

    public Ungergraduate(String Name) throws SomeException {
        super(Name);
    }

    /**
     *
     */
    @Override
    public void study() {
        System.out.println("Junior "+this.getStudentName()+" is using classroom");
        this.setLearnedClass(this.getLearnedClass()+1);
    }
}
