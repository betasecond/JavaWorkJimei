package edu.jimei.StarCraft.races;

import edu.jimei.StarCraft.abstracts.Creature;
import edu.jimei.StarCraft.interfaces.TerranInterface;

public class Terran extends Creature implements TerranInterface  {
    protected int technologyLevel;
    protected int resources;
    protected int militaryStrength;

    /**
     *
     */
    @Override
    public void fight() {

    }

    /**
     *
     */
    @Override
    public void move() {

    }

    /**
     *
     */
    @Override
    public void repair() {

    }
}
