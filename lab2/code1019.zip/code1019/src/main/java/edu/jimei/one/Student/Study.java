package edu.jimei.one.Student;

public interface Study {
    void study();
}
