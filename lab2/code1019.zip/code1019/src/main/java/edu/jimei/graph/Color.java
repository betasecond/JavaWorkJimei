package edu.jimei.graph;

import lombok.Getter;
import lombok.Setter;

@Getter
public enum Color {
    RED("#FF0000"),
    GREEN("#00FF00"),
    BLUE("#0000FF"),
    YELLOW("#FFFF00"); // 这里可以继续添加更多颜色

    // 成员变量，代表颜色的十六进制代码
    private final String code;

    // 构造方法，用于给枚举常量关联数据（颜色代码）
    Color(String code) {
        this.code = code;
    }

    // 方法，获取相关联的颜色代码
    public String getCode() {
        return this.code;
    }

    public static Color forCode(String code) {
        for (Color color : Color.values()) {
            if (color.getCode().equals(code)) {
                return color;
            }
        }
        return null; // 如果没有匹配的颜色代码，返回null
    }

}