package edu.jimei.StarCraft.interfaces;

public interface ProtossInterface extends RaceInterface{
    void recover();
    void repair();
}
