package edu.jimei.StarCraft.races;

import edu.jimei.StarCraft.abstracts.Creature;
import edu.jimei.StarCraft.interfaces.ProtossInterface;

public class Protoss extends Creature implements ProtossInterface {
    protected int energyLevel;
    protected int ancientKnowledge;
    protected int shieldCapacity;
    /**
     *
     */
    @Override
    public void move() {

    }

    /**
     *
     */
    @Override
    public void recover() {

    }

    /**
     *
     */
    @Override
    public void repair() {

    }
}
