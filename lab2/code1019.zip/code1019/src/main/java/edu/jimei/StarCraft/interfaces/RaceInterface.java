package edu.jimei.StarCraft.interfaces;

public interface RaceInterface {
    void fight();
    void move();
}
