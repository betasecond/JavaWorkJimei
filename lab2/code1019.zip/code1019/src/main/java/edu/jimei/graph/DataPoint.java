package edu.jimei.graph;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class DataPoint {
    private Double x;
    private Double y;
    private String id;

    public DataPoint(Double key1, Double key2, String value) {
        this.x = key1;
        this.y = key2;
        this.id = value;
    }
}
