package edu.jimei.graph;

import edu.jimei.SomeException;
import edu.jimei.graph.Circle;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ShapeTest {

    private Circle circle;
    private Vertical vertical;

    @BeforeEach
    void setUp() {
        circle = new Circle();
        vertical = new Vertical();
    }

    @Test
    void testCircleAddPoints() {
        circle.addPoints(1.0, 1.0, "A");
        circle.addPoints(2.0, 1.0, "B");
        circle.addPoints(1.5, 1.5, "C");
        assertEquals(3, circle.getDataPoints().size());
    }

    @Test
    void testVerticalAddPoints() {
        vertical.addPoints(1.0, 1.0, "D1");
        vertical.addPoints(2.0, 2.0, "D2");
        assertEquals(2, vertical.getDataPoints().size());
    }

    @Test
    void testCircleArea() throws SomeException {
        circle.addPoints(1.0, 1.0, "A");
        circle.addPoints(2.0, 1.0, "B");
        circle.addPoints(1.5, 1.5, "C");
        double expectedArea = Math.PI;  // Assuming radius is 1.0
        assertEquals(expectedArea, circle.getArea(), 0.01);  // Tolerance of 0.01
    }

    @Test
    void testVerticalArea() throws SomeException {
        vertical.addPoints(1.0, 1.0, "D1");
        vertical.addPoints(2.0, 2.0, "D2");
        double expectedArea = 1.0;  // Assuming width is 1.0 and height is 1.0
        assertEquals(expectedArea, vertical.getArea(), 0.01);  // Tolerance of 0.01
    }

    @Test
    void testCircleInvalidArea() {
        assertThrows(SomeException.class, () -> circle.getArea());  // Should throw exception if no points are added
    }

    @Test
    void testVerticalInvalidArea() {
        assertThrows(SomeException.class, () -> vertical.getArea());  // Should throw exception if no points are added
    }
}
