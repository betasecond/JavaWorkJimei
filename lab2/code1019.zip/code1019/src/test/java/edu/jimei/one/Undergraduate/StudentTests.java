package edu.jimei.one.Undergraduate;

import edu.jimei.SomeException;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class StudentTests {

    @Before
    public void setUp() {

    }

    @Test
    public void testUndergraduateStudy() throws SomeException {
        Ungergraduate undergraduate = new Ungergraduate("Alice");
        undergraduate.study();
        assertEquals(1, undergraduate.getLearnedClass());
    }

    @Test(expected = SomeException.class)
    public void testInvalidName() throws SomeException {
        Ungergraduate invalidUndergraduate = new Ungergraduate("None");
    }

    @Test
    public void testUndergraduateMultipleStudies() throws SomeException {
        Ungergraduate undergraduate = new Ungergraduate("Bob");
        for (int i = 0; i < 100; i++) {
            undergraduate.study();
        }
        assertEquals(100, undergraduate.getLearnedClass());
    }
}
