package edu.jimei.StarCraft.battle;

import edu.jimei.StarCraft.TerranUnits.Marine;
import edu.jimei.StarCraft.ZergUnits.Zergling;


public class Battle {

    public static void main(String[] args) {
        Marine marine = new Marine();
        Zergling zergling = new Zergling();

        int turn = 1;

        while (marine.getLife() > 0 && zergling.getLife() > 0) {
            System.out.println("----- Turn " + turn + " -----");

            // Marine attacks Zergling
            zergling.takeDamage(marine.getAttackDamage());
            System.out.println("Marine attacks Zergling. Zergling's life: " + zergling.getLife());

            // Check if Zergling is defeated
            if (zergling.getLife() <= 0) {
                System.out.println("Marine wins!");
                break;
            }

            // Zergling attacks Marine
            marine.takeDamage(zergling.getAttackDamage());
            System.out.println("Zergling attacks Marine. Marine's life: " + marine.getLife());

            // Check if Marine is defeated
            if (marine.getLife() <= 0) {
                System.out.println("Zergling wins!");
                break;
            }

            turn++;
        }
    }
}


